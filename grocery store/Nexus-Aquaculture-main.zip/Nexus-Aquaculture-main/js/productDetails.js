const params = new URLSearchParams(window.location.search);
const category = params.get("category");

window.onload = function () {

    const user = JSON.parse(localStorage.getItem("user"));

    if (!user) {
        document.getElementById("logoutBtn").style.display = "none";
    }

}

/* LOAD PRODUCTS */

async function loadProduct() {

    try {

        const res = await fetch("http://localhost:5000/api/products");
        const products = await res.json();

        const container = document.getElementById("productDetails");
        const title = document.getElementById("productName");

        container.innerHTML = "";

        if (!category) {
            container.innerHTML = "Invalid category";
            return;
        }

        title.innerText = category + " Products";

        /* CATEGORY FILTER */

        const filteredProducts = products.filter(
            p => p.category && p.category.toLowerCase().includes(category.toLowerCase())
        );

        if (filteredProducts.length === 0) {
            container.innerHTML = "No products available.";
            return;
        }

        /* LOOP PRODUCTS */

        filteredProducts.forEach((p, index) => {

            let detailsHTML = "";

            /* -------- FISH -------- */

            if (p.category && p.category.toLowerCase().includes("fish")) {

                detailsHTML = `
<div class="detail-card">

<span class="status-badge">${p.status}</span>

<h2>${p.name}</h2>

<p><strong>Average Size:</strong> ${p.weight} kg</p>
<p><strong>Stock:</strong> ${p.stock} kg/ton</p>
<p><strong>Price:</strong> ₹${p.price} / kg</p>
<p><strong>Minimum Order:</strong> ${p.minOrder} kg</p>

<div class="quantity-box">

<label>Order Quantity</label>

<div class="qty-control">

<button onclick="changeQty('minus',${p.id},${p.minOrder})">−</button>

<input
type="number"
id="qty-${p.id}"
class="qty-input"
value="${p.minOrder}"
min="${p.minOrder}"
readonly
>

<button onclick="changeQty('plus',${p.id},${p.minOrder})">+</button>

</div>

</div>

<div class="action-buttons">

<button class="order-btn"
onclick='orderProduct(${JSON.stringify(p)})'>
Order Now
</button>

<a href="contact.html" class="contact-btn">Contact Us</a>

</div>

</div>
`;

            }

            /* -------- FEED / MEDICINE -------- */

            else if (p.category === "Feed" || p.category === "Medicine" || p.category === "Fry" || p.category === "Fingerlings") {

                detailsHTML = `
<div class="detail-card" style="animation-delay:${index * 0.15}s">

<h2>${p.name || ""}</h2>

<p><strong>Stock:</strong> ${p.stock || ""}/kg</p>
<p><strong>Price:</strong> ₹${p.price || ""}/kg</p>
<p><strong>Minimum Order:</strong> ${p.minOrder || ""}/kg</p>
<p><strong>Status:</strong> ${p.status || ""}</p>

<p><strong>Description:</strong> ${p.description || ""}</p>

<div class="quantity-box">

<label>Order Quantity</label>

<div class="qty-control">

<button onclick="changeQty('minus',${p.id},${p.minOrder || 1})">−</button>

<input
type="number"
id="qty-${p.id}"
class="qty-input"
value="${p.minOrder || 1}"
min="${p.minOrder || 1}"
readonly
>

<button onclick="changeQty('plus',${p.id},${p.minOrder || 1})">+</button>

</div>

</div>

<div class="btn-group">

<button class="order-btn"
onclick='orderProduct(${JSON.stringify(p)})'>
Order Now
</button>

<a href="contact.html" class="contact-btn">Contact Us</a>

</div>

</div>
`;

            }

            /* -------- SUPPLY -------- */

            else if (p.category === "Supply") {

                detailsHTML = `
<div class="detail-card" style="animation-delay:${index * 0.15}s">

<h2>${p.name || ""}</h2>

<p><strong>Supply Quantity:</strong> ${p.weight || ""}/kg</p>
<p><strong>Price:</strong> ₹${p.price || ""}</p>
<p><strong>Status:</strong> ${p.status || ""}</p>

<p><strong>Describtion:</strong>${p.description || ""}</p>

<div class="quantity-box">

<label>Order Quantity</label>

<div class="qty-control">

<button onclick="changeQty('minus',${p.id},${p.minOrder || 1})">−</button>

<input
type="number"
id="qty-${p.id}"
class="qty-input"
value="${p.minOrder || 1}"
min="${p.minOrder || 1}"
readonly
>

<button onclick="changeQty('plus',${p.id},${p.minOrder || 1})">+</button>

</div>

</div>

<div class="btn-group">

<button class="order-btn"
onclick='orderProduct(${JSON.stringify(p)})'>
Order Now
</button>

<a href="contact.html" class="contact-btn">Contact Us</a>

</div>

</div>
`;

            }

            container.innerHTML += detailsHTML;

        });

    } catch (err) {

        console.error(err);

        document.getElementById("productDetails").innerHTML =
            "Error loading product details.";

    }

}

loadProduct();

/* ORDER FUNCTION */

function orderProduct(p) {

    const user = JSON.parse(localStorage.getItem("user"));

    if (!user) {
        window.location.href = "userLogin.html";
        return;
    }

    const qty = document.getElementById(`qty-${p.id}`).value;

    const ownerNumber = "919113354669";

    let message = `New Order

Product: ${p.name}
Category: ${p.category}

Price: ₹${p.price}
Minimum Order: ${p.minOrder}

Size / Weight: ${p.weight || "N/A"}
Stock: ${p.stock || "N/A"}

Requested Quantity: ${qty}

Customer Name: ${user.fullname}
Phone: ${user.phone}

Address:
${user.address}
${user.city} - ${user.pincode}
`;

    const whatsappURL =
        `https://wa.me/${ownerNumber}?text=${encodeURIComponent(message)}`;

    window.open(whatsappURL, "_blank");

}

/* QUANTITY CONTROL */

function changeQty(type, id, min) {

    const input = document.getElementById(`qty-${id}`);

    let value = parseInt(input.value);

    if (type === "plus") {
        value += 1;
    }

    if (type === "minus") {

        if (value <= min) {
            alert(`Minimum order is ${min}`);
            return;
        }

        value -= 1;

    }

    input.value = value;

}

/* LOGOUT */

function logoutUser() {

    localStorage.removeItem("user");

    alert("Logged out successfully");

    window.location.href = "userLogin.html";

}

