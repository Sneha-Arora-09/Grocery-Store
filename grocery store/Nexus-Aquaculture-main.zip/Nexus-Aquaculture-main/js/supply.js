async function loadSupplyData() {

    const res = await fetch("http://localhost:5000/api/products");
    const products = await res.json();

    products.forEach(p => {

        if (p.name.toLowerCase() === "singhi fish") {

            document.getElementById("singhiWeight").innerText = p.weight;
            document.getElementById("singhiPrice").innerText = p.price;
            document.getElementById("singhiMin").innerText = p.minOrder;
            document.getElementById("singhiStatus").innerText = p.status;

        }

        if (p.name.toLowerCase() === "desi mangur") {

            document.getElementById("mangurWeight").innerText = p.weight;
            document.getElementById("mangurPrice").innerText = p.price;
            document.getElementById("mangurMin").innerText = p.minOrder;
            document.getElementById("mangurStatus").innerText = p.status;

        }

    });

}

async function loadSupply() {

    const res = await fetch("http://localhost:5000/api/getSupply");
    const data = await res.json();

    data.forEach(item => {

        if (item.name === "Singhi Fish") {
            document.getElementById("singhiWeight").innerText = item.weight;
            document.getElementById("singhiPrice").innerText = item.price;
            document.getElementById("singhiMin").innerText = item.minOrder;
            document.getElementById("singhiStatus").innerText = item.status;
        }

        if (item.name === "Desi Mangur") {
            document.getElementById("mangurWeight").innerText = item.weight;
            document.getElementById("mangurPrice").innerText = item.price;
            document.getElementById("mangurMin").innerText = item.minOrder;
            document.getElementById("mangurStatus").innerText = item.status;
        }

    });

}

loadSupply();

loadSupplyData();