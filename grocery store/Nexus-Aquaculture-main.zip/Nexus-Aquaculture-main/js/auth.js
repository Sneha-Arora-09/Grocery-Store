// TAB SWITCH


function showSignup(){

document.getElementById("loginForm").style.display="none";
document.getElementById("signupForm").style.display="block";

}

function showLogin(){

document.getElementById("loginForm").style.display="block";
document.getElementById("signupForm").style.display="none";

}



// SIGNUP

document.getElementById("signupForm").addEventListener("submit",function(e){

e.preventDefault();

let password=document.getElementById("password").value;
let confirm=document.getElementById("confirmPassword").value;

if(password!==confirm){

alert("Passwords do not match");
return;

}

let user={

name:document.getElementById("name").value,
phone:document.getElementById("phone").value,
password:password,
address:document.getElementById("address").value,
city:document.getElementById("city").value,
pincode:document.getElementById("pincode").value

};

localStorage.setItem("user",JSON.stringify(user));

alert("Account Created Successfully");

showLogin();

});




// LOGIN

document.getElementById("loginForm").addEventListener("submit",function(e){

e.preventDefault();

let phone=document.getElementById("loginPhone").value;
let password=document.getElementById("loginPassword").value;

let user=JSON.parse(localStorage.getItem("user"));

if(user && phone===user.phone && password===user.password){

localStorage.setItem("loggedIn","true");

alert("Login Successful");

window.location.href="index.html";

}else{

alert("Invalid Phone or Password");

}

});




// ADMIN PORTAL

function openAdmin(){

document.getElementById("adminModal").style.display="flex";

}



// ADMIN LOGIN

function adminLogin() {

let username = document.getElementById("adminUser").value;
let password = document.getElementById("adminPass").value;

if (username === "admin" && password === "admin123") {

alert("Admin Login Successful");

// OPEN ADMIN PAGE
window.location.href = "admin.html";

} else {

alert("Invalid Admin Credentials");

}

}


function loginUser(){

// after checking username & password

localStorage.setItem("userLoggedIn","true");

window.location.href="index.html";

}

function toggleMenu(){
document.getElementById("navLinks").classList.toggle("active");
}


function submitEnquiry() {
  const phone = document.getElementById("phone").value;

  const pattern = /^[0-9]{10}$/;

  if (!pattern.test(phone)) {
    alert("Phone number must be exactly 10 digits");
    return; // stop function
  }

  // continue your existing code
  alert("Form submitted successfully");
}
