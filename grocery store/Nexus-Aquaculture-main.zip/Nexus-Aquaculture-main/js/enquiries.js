/* SUBMIT ENQUIRY FROM CONTACT PAGE */

async function submitEnquiry(){

const name=document.getElementById("name").value;
const phone=document.getElementById("phone").value;
const quantity=document.getElementById("quantity").value;
const message=document.getElementById("message").value;

if(!name || !phone || !quantity){
alert("Please fill all required fields");
return;
}

await fetch("http://localhost:5000/api/enquiry",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({
name,
phone,
quantity,
message
})

});

alert("Enquiry Submitted Successfully");

document.getElementById("enquiryForm").reset();

}


/* LOAD ENQUIRIES IN ADMIN PAGE */

async function loadEnquiries(){

const table = document.getElementById("enquiryTable");

if(!table){
console.log("Table not found");
return;
}

const res = await fetch("http://localhost:5000/api/enquiries");
const data = await res.json();

table.innerHTML = "";

data.forEach(e => {

table.innerHTML += `
<tr>

<td>${e.name}</td>
<td>${e.phone}</td>
<td>${e.quantity}</td>
<td>${e.message}</td>
<td class="enquiry-date">${e.date}</td>

<td>
<div class="action-buttons">

<button class="btn-whatsapp" onclick="replyWhatsApp('${e.phone}','${e.name}')">
WhatsApp
</button>

<button class="btn-delete" onclick="deleteEnquiry(${e.id})">
Delete
</button>

</div>
</td>

</tr>
`;

});

}


/* DELETE ENQUIRY */

async function deleteEnquiry(id){

if(!confirm("Delete this enquiry?")) return;

await fetch(`http://localhost:5000/api/enquiries/${id}`,{
method:"DELETE"
});

loadEnquiries();

}


/* WHATSAPP REPLY */

function replyWhatsApp(phone,name){

const text=`Hello ${name}, thank you for contacting Singhi Aquafarms.`;

const url=`https://wa.me/91${phone}?text=${encodeURIComponent(text)}`;

window.open(url,"_blank");

}


/* RUN ONLY IF ADMIN TABLE EXISTS */

document.addEventListener("DOMContentLoaded",loadEnquiries);