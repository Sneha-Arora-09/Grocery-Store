 function changeForm() {

            const category = document.getElementById("category").value;
            const container = document.getElementById("dynamicFields");

            let html = "";

            /* -------- FISH FORM -------- */

            if (category === "Fish") {

                html = `
<input type="number" id="weight" placeholder="Average Size (200g – 800g)" required>
<input type="number" id="stock" placeholder="Stock (kg / ton)" required>
<input  type="number" id="price" placeholder="Price per kg" required>
<input  type="number" id="minOrder" placeholder="Minimum Order" required>
<select id="status">
<option>Available</option>
<option>Limited</option>
<option>Out of Stock</option>
</select>
<textarea id="description" placeholder="Fish Details" required></textarea>
`;

            }

            /* -------- FRY -------- */

            else if (category === "Fry") {

                html = `
<input  type="number" id="weight" placeholder="Fry Size" required>
<input  type="number" id="stock" placeholder="Available Quantity" required>
<input type="number"  id="price" placeholder="Price" required>
<input   type="number" id="minOrder" placeholder="Minimum Order" required>
<select id="status">
<option>Available</option>
<option>Limited</option>
<option>Out of Stock</option>
</select>
<textarea id="description" placeholder="Fry Details" required></textarea>
`;

            }

            /* -------- FINGERLINGS -------- */

            else if (category === "Fingerlings") {

                html = `
<input type="number"  id="weight" placeholder="Fingerling Size" required>
<input  type="number" id="stock" placeholder="Available Quantity" required>
<input  type="number" id="price" placeholder="Price" required>
<input  type="number" id="minOrder" placeholder="Minimum Order" required>
<select id="status">
<option>Available</option>
<option>Limited</option>
<option>Out of Stock</option>
</select>
<textarea id="description" placeholder="Fingerling Details" required></textarea>
`;

            }

            /* -------- FEED -------- */

            else if (category === "Feed") {

                html = `
<input  type="number" id="stock" placeholder="Available Bags / Quantity" required>
<input  type="number" id="price" placeholder="Price per bag" required>
<input  type="number"  id="minOrder" placeholder="Minimum Order"  required>
<select id="status">
<option>Available</option>
<option>Limited</option>
<option>Out of Stock</option>
</select>
<textarea id="description" placeholder="Feed Details" required></textarea>
`;

            }

            /* -------- MEDICINE -------- */

            else if (category === "Medicine") {

                html = `
<input  type="number" id="stock" placeholder="Available Units" required>
<input  type="number" id="price" placeholder="Price" required>
<input  type="number" id="minOrder" placeholder="Minimum Order" required>
<select id="status">
<option>Available</option>
<option>Limited</option>
<option>Out of Stock</option>
</select>
<textarea id="description" placeholder="Medicine Description" required></textarea>
`;

            }

            /* -------- SUPPLY -------- */

            else if (category === "Supply") {

                html = `
<input type="number"  id="weight" placeholder="Supply Quantity" required>
<input  type="number" id="price" placeholder="Price" required>
<select id="status" required>
<option>Available</option>
<option>Limited</option>
<option>Out of Stock</option>
</select>
<textarea id="description" placeholder="Supply Details" required></textarea>
`;

            }

            container.innerHTML = html;

        }

        const form = document.getElementById("addProductForm");

        document.addEventListener("submit", async function (e) {

            if (e.target.id !== "addProductForm") return;

            e.preventDefault();

            const name = document.getElementById("name").value;
            const category = document.getElementById("category").value;

            const weight = document.getElementById("weight")?.value || "";
            const price = document.getElementById("price")?.value || "";
            const minOrder = document.getElementById("minOrder")?.value || "";
            const stock = document.getElementById("stock")?.value || "";
            const status = document.getElementById("status")?.value || "";
            const description = document.getElementById("description")?.value || "";

            await fetch("http://localhost:5000/api/products", {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    name,
                    category,
                    weight,
                    price,
                    minOrder,
                    stock,
                    status,
                    description
                })

            });

            alert("Product Added");

            if (typeof loadProducts === "function") {
                loadProducts();
            }

            document.getElementById("formContainer").innerHTML = "";

        });