async function fetchProducts() {

    const res = await fetch("http://localhost:5000/api/products");

    const data = await res.json();

    const container = document.getElementById("productContainer");
    container.innerHTML = "";

    if (!container) {
        console.error("productContainer not found");
        return;
    }

    container.innerHTML = "";

    data.forEach(p => {

        let label = "Average Size";

        if (p.category === "Supply") {
            label = "Weight";
        }

        container.innerHTML += `
<div class="product-card">

<h3>${p.name}</h3>

<p>${label}: ${p.weight}</p>

<a href="productDetails.html?id=${p.id}">
View Details
</a>

</div>
`;

    });

}

fetchProducts();


