async function saveSupply() {

    const data = {

        singhi: {
            weight: document.getElementById("singhiWeight").value,
            price: document.getElementById("singhiPrice").value,
            minOrder: document.getElementById("singhiMin").value,
            status: document.getElementById("singhiStatus").value
        },

        mangur: {
            weight: document.getElementById("mangurWeight").value,
            price: document.getElementById("mangurPrice").value,
            minOrder: document.getElementById("mangurMin").value,
            status: document.getElementById("mangurStatus").value
        }

    };

    await fetch("http://localhost:5000/api/updateSupply", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    });

    alert("Supply Page Updated");

}