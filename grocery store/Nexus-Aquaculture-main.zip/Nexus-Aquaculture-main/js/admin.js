/* LOAD PRODUCTS */

async function loadProducts() {

    const res = await fetch("http://localhost:5000/api/products");
    const data = await res.json();

    const table = document.getElementById("productTable");
    const tableContainer = document.getElementById("productTableContainer");

    table.innerHTML = "";

    if (data.length === 0) {
        tableContainer.style.display = "none";
        return;
    }

    tableContainer.style.display = "table";

    data.forEach(p => {

        table.innerHTML += `
<tr>

<td>${p.category || ""}</td>
<td>${p.name || ""}</td>
<td>${p.stock || ""}</td>
<td>${p.weight || ""}</td>
<td>${p.price ? "₹" + p.price : ""}</td>
<td>${p.minOrder || ""}</td>
<td>${p.status || ""}</td>

<td>
<button onclick="editProduct(${p.id})">Edit</button>
<button onclick="deleteProduct(${p.id})">Delete</button>
</td>

</tr>
`;

    });

}



/* DELETE PRODUCT */

async function deleteProduct(id) {

    if (!confirm("Delete this product?")) return;

    await fetch(`http://localhost:5000/api/products/${id}`, {
        method: "DELETE"
    });

    loadProducts();

}



/* EDIT PRODUCT */

async function editProduct(id){

const res = await fetch(`http://localhost:5000/api/products/${id}`);
const p = await res.json();

const container = document.getElementById("formContainer");

container.innerHTML = `

<h3>Edit Product</h3>

<input id="editName" value="${p.name}" placeholder="Product Name">

<input id="editWeight" value="${p.weight}" placeholder="Average Size">

<input id="editStock" value="${p.stock}" placeholder="Stock">

<input id="editPrice" value="${p.price}" placeholder="Price">

<input id="editMinOrder" value="${p.minOrder}" placeholder="Minimum Order">

<select id="editStatus">

<option ${p.status==="Available"?"selected":""}>Available</option>
<option ${p.status==="Limited"?"selected":""}>Limited</option>
<option ${p.status==="Out of Stock"?"selected":""}>Out of Stock</option>

</select>

<textarea id="editDescription">${p.description || ""}</textarea>

<br><br>

<button onclick="updateProduct(${p.id})">Update</button>

<button onclick="document.getElementById('formContainer').innerHTML=''">Cancel</button>

`;

/* auto scroll to edit form */
container.scrollIntoView({behavior:"smooth"});

}


/* UPDATE PRODUCT */

async function updateProduct(id) {

    const name = document.getElementById("editName").value;
    const weight = document.getElementById("editWeight").value;
    const stock = document.getElementById("editStock").value;
    const price = document.getElementById("editPrice").value;
    const minOrder = document.getElementById("editMinOrder").value;
    const status = document.getElementById("editStatus").value;
    const description = document.getElementById("editDescription").value;

    /* required validation */

    if (!name || !weight || !stock || !price || !minOrder || !status) {
        alert("Please fill all required fields");
        return;
    }

    await fetch(`http://localhost:5000/api/products/${id}`, {

        method: "PUT",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({
            name,
            weight,
            price,
            minOrder,
            stock,
            status,
            description
        })

    });

    alert("Product Updated Successfully");

    document.getElementById("formContainer").innerHTML = "";

    loadProducts();

}



/* SHOW ADD PRODUCT FORM */

function showAddForm(){

fetch("addProduct.html")
.then(res => res.text())
.then(html => {

const container = document.getElementById("formContainer");

container.innerHTML = html;

/* activate scripts inside loaded HTML */
const scripts = container.querySelectorAll("script");

scripts.forEach(script => {

    const newScript = document.createElement("script");

    if (script.src) {
        newScript.src = script.src;   // load external script
    } else {
        newScript.textContent = script.textContent;
    }

    document.body.appendChild(newScript);

});

/* auto scroll to form */
container.scrollIntoView({behavior:"smooth"});

});

}



/* ADD PRODUCT */

async function addProduct() {

    const name = document.getElementById("name").value;
    const category = document.getElementById("category").value;
    const weight = document.getElementById("weight").value;
    const price = document.getElementById("price").value;
    const minOrder = document.getElementById("minOrder").value;
    const stock = document.getElementById("stock").value;
    const status = document.getElementById("status").value;
    const description = document.getElementById("description").value;

    /* required validation */

    if (!name || !category || !weight || !price || !minOrder || !stock || !status) {
        alert("Please fill all fields before submitting");
        return;
    }

    await fetch("http://localhost:5000/api/products", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({
            name,
            category,
            weight,
            price,
            minOrder,
            stock,
            status,
            description
        })

    });

    alert("Product Added Successfully");

    document.getElementById("formContainer").innerHTML = "";

    loadProducts();

}

function openSupplyEditor(){

fetch("editSupply.html")

.then(res => res.text())

.then(html => {

const container = document.getElementById("formContainer");

container.innerHTML = html;

/* scroll automatically */
container.scrollIntoView({
behavior:"smooth"
});

});

}

/* LOAD PRODUCTS WHEN PAGE OPENS */

loadProducts();

/* OPEN ENQUIRIES PAGE */

function openEnquiries(){

fetch("enquiries.html")

.then(res => res.text())

.then(html => {

const container = document.getElementById("formContainer");

container.innerHTML = html;

/* run enquiry loader AFTER html appears */

loadEnquiries();

/* scroll to section */

container.scrollIntoView({
behavior:"smooth"
});

});

}

/* LOAD ENQUIRY COUNT */

async function loadEnquiryCount(){

const res = await fetch("http://localhost:5000/api/enquiries");

const data = await res.json();

document.getElementById("enquiryCount").innerText = `(${data.length})`;

}

/* run when admin page loads */

loadEnquiryCount();

function toggleAdminMenu(){
document.querySelector(".sidebar").classList.toggle("active");
}