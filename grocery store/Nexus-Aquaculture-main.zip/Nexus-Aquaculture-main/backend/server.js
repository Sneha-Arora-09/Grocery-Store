
const express = require("express");
const cors = require("cors");
const sqlite3 = require("sqlite3").verbose();

const productRoutes = require("./routes/productRoutes");
const authRoutes = require("./routes/authRoutes");
const userRoutes = require("./routes/userRoutes");

const app = express();

app.use(cors());
app.use(express.json());
app.use("/api/users", userRoutes);

/* DATABASE CONNECTION */

const db = new sqlite3.Database("./database.db", (err) => {
  if (err) {
    console.error("Database error:", err.message);
  } else {
    console.log("Connected to SQLite database");
  }
});

/* CREATE TABLE */

db.serialize(() => {

  db.run(`
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      category TEXT,
      weight TEXT,
      price INTEGER,
      minOrder TEXT,
      stock TEXT,
      status TEXT,
      description TEXT
    )
  `);

});

/* ROUTES */

/* ROUTES */

app.use("/api/products", productRoutes);
app.use("/api/auth", authRoutes);

/* GET SUPPLY DATA */

app.get("/api/getSupply", (req, res) => {

  db.all("SELECT * FROM supply", (err, rows) => {
    if (err) {
      res.status(500).json(err);
    } else {
      res.json(rows);
    }
  });

});

/* UPDATE SUPPLY */

app.post("/api/updateSupply", (req, res) => {

  const { singhi, mangur } = req.body;

  db.run(
    "UPDATE supply SET weight=?,price=?,minOrder=?,status=? WHERE name='Singhi Fish'",
    [singhi.weight, singhi.price, singhi.minOrder, singhi.status]
  );

  db.run(
    "UPDATE supply SET weight=?,price=?,minOrder=?,status=? WHERE name='Desi Mangur'",
    [mangur.weight, mangur.price, mangur.minOrder, mangur.status]
  );

  res.json({ message: "Supply updated" });

});

/* CREATE TABLES */

db.serialize(() => {

  db.run(`
CREATE TABLE IF NOT EXISTS enquiries(
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
phone TEXT,
quantity TEXT,
message TEXT,
date DATETIME DEFAULT CURRENT_TIMESTAMP
)
`);

});

/* SAVE ENQUIRY */

app.post("/api/enquiry", (req, res) => {

  const { name, phone, quantity, message } = req.body;

  db.run(
    "INSERT INTO enquiries(name,phone,quantity,message) VALUES(?,?,?,?)",
    [name, phone, quantity, message],
    function (err) {

      if (err) {
        res.status(500).json(err);
      } else {
        res.json({ message: "Enquiry saved" });
      }

    });

});

/* GET ALL ENQUIRIES */

app.get("/api/enquiries", (req, res) => {

  db.all("SELECT * FROM enquiries ORDER BY id DESC", (err, rows) => {

    if (err) {
      res.status(500).json(err);
    } else {
      res.json(rows);
    }

  });

});

/* DELETE ENQUIRY */

app.delete("/api/enquiries/:id", (req, res) => {

  const id = req.params.id;

  db.run(
    "DELETE FROM enquiries WHERE id=?",
    [id],
    function (err) {

      if (err) {
        res.status(500).json(err);
      } else {
        res.json({ message: "Deleted" });
      }

    });

});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});


