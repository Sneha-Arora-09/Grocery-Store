const sqlite3 = require("sqlite3").verbose();

const db = new sqlite3.Database("./database.db", (err) => {
 if (err) {
   console.log(err.message);
 } else {
   console.log("SQLite Database Connected");
 }
});

db.run(`
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT,
 category TEXT,
 weight TEXT,
 price INTEGER,
 minOrder TEXT,
 stock INTEGER,
 status TEXT,
 description TEXT
)
`);

db.run(`
CREATE TABLE IF NOT EXISTS admin (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT,
 password TEXT
)
`);

db.run(`
CREATE TABLE IF NOT EXISTS users (
id INTEGER PRIMARY KEY AUTOINCREMENT,
fullname TEXT,
phone TEXT UNIQUE,
password TEXT,
address TEXT,
city TEXT,
pincode TEXT

)
`);

db.serialize(() => {

db.run(`
CREATE TABLE IF NOT EXISTS supply (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
weight TEXT,
price INTEGER,
minOrder TEXT,
status TEXT
)
`);

db.run(`
INSERT OR IGNORE INTO supply (id,name,weight,price,minOrder,status)
VALUES
(1,'Singhi Fish','100','320','50','Available'),
(2,'Desi Mangur','80','290','40','Available')
`);

});
module.exports = db;