const express = require("express");
const router = express.Router();
const db = require("../database");

/* SIGNUP */

router.post("/signup",(req,res)=>{

const {fullname,phone,password,address,city,pincode}=req.body;

db.get("SELECT * FROM users WHERE phone=?",[phone],(err,user)=>{

if(user){
return res.json({message:"User already exists"});
}

db.run(
`INSERT INTO users(fullname,phone,password,address,city,pincode)
VALUES(?,?,?,?,?,?)`,
[fullname,phone,password,address,city,pincode],
function(err){

if(err){
return res.status(500).json(err);
}

res.json({message:"Signup successful"});

});

});

});

/* LOGIN */

router.post("/login",(req,res)=>{

const {phone,password}=req.body;

db.get(
"SELECT * FROM users WHERE phone=? AND password=?",
[phone,password],
(err,user)=>{

if(!user){
return res.json({message:"Invalid credentials"});
}

res.json(user);

});

});

module.exports = router;