const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");

const adminUser = {
    username: "admin",
    password: "admin123"
};

router.post("/login", (req, res) => {

    const { username, password } = req.body;

    if (username === adminUser.username && password === adminUser.password) {

        const token = jwt.sign({ user: username }, "secret", { expiresIn: "1h" });

        res.json({
            token: token,
            role: "admin"
        });

    } else {
        res.status(401).json({ message: "Invalid login" });
    }

});

module.exports = router;