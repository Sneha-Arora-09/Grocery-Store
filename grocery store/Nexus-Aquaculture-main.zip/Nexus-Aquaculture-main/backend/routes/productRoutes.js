const express = require("express");
const router = express.Router();

const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database("./database.db");


// GET ALL PRODUCTS
router.get("/", (req, res) => {

  db.all("SELECT * FROM products", [], (err, rows) => {

    if (err) return res.json(err);

    res.json(rows);

  });

});


// GET PRODUCT BY ID
router.get("/:id", (req, res) => {

  db.get(
    "SELECT * FROM products WHERE id=?",
    [req.params.id],
    (err, row) => {

      if (err) return res.json(err);

      res.json(row);

    });

});


// ADD PRODUCT
router.post("/", (req, res) => {

const { name, category, weight, price, minOrder, stock, status, description } = req.body;

db.run(
`INSERT INTO products (name, category, weight, price, minOrder, stock, status, description)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
[name, category, weight, price, minOrder, stock, status, description],
function(err){

if(err){
console.log(err);
return res.status(500).json(err);
}

res.json({ id: this.lastID });

});

});




// UPDATE PRODUCT
router.put("/:id", (req, res) => {

  const { name, weight, price, minOrder, stock, status, description } = req.body;

  db.run(
    `UPDATE products 
     SET name=?, weight=?, price=?, minOrder=?, stock=?, status=?, description=? 
     WHERE id=?`,
    [name, weight, price, minOrder, stock, status, description, req.params.id],
    function (err) {

      if (err) {
        res.status(500).json(err);
        return;
      }

      res.json({ message: "Product Updated" });

    }
  );

});


// DELETE PRODUCT
router.delete("/:id", (req, res) => {

  db.run(
    "DELETE FROM products WHERE id=?",
    [req.params.id],
    function (err) {

      if (err) {
        res.status(500).json(err);
        return;
      }

      res.json({ message: "Product Deleted" });

    }
  );

});


module.exports = router;